<div id="header">
    <!-- <section>
        <ul class="right">
        
    </section> -->
    
    
        <a href="index.php"><strong><?php echo "HI"; ?></strong> Geek</a>
    </div>
