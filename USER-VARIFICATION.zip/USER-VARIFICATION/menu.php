
 <?php 
echo '<table width="1000"> 
<tr><td><a href="index.php">Home</a></td> 
<td align="right"><a href="index.php?logout=1 " class="logout">logout</td> 
</tr> 
</table>'; 
?>
