<?php require_once 'controllers/authController.php'; ?>
<html>
<head>

<title> Password Message</title>
</head>
<body>
    <form method="post" action="forgot_password.php" >
    <h3 >Password Message</h3>
    <p>
    An email has been set to your email
     address with link to reset your email address.
    </p>

</body>
</html>