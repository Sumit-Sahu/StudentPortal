<div class="endsec">


<a href="https://www.iiitdmj.ac.in/" target="blank"><h3 align="center" class="foothead" > PDPM <br> Indian Institute of Information Technology Design and Manufacturing Jabalpur </h3></a>

  <div class="row" style="width:1000px; margin-left:8vw;">
    <div class="col-sm">
      <ul>
        <li><a href="https://www.iiitdmj.ac.in/placement.iiitdmj.ac.in/">Placement</a></li>
        <li><a href="https://www.iiitdmj.ac.in/students/activities.php">Activities</a></li>
        <li><a href="https://www.iiitdmj.ac.in/students/gymkhana/gymkhana.php">Gymkhana</a></li>
        <li><a href="https://www.iiitdmj.ac.in/students/achievements.php">Achievements</a></li>


      </ul>
    </div>

    <div class="col-sm">
      <ul>
        <li><a href="https://www.iiitdmj.ac.in/students/councelling.php">Counselling</a></li>
        <li><a href="https://www.iiitdmj.ac.in/students/hostels.php">Hostel</a></li>
        <li><a href="https://www.iiitdmj.ac.in/students/PHC.php">Primary Health Care</a></li>
        <li><a href="https://www.iiitdmj.ac.in/students/mess.php">Student Mess</a></li>



      </ul>
    </div>

    <div class="col-sm">
      <ul>
        <li><a href="https://www.iiitdmj.ac.in/sac.iiitdmj.ac.in">Alumni cell</a></li>
        <li><a href="https://www.iiitdmj.ac.in/cc.iiitdmj.ac.in">Computer Center</a></li>
        <li><a href="http://web.iiitdmj.ac.in/library.html">Library</a></li>

      </ul>
    </div>

    <div class="col-sm">
      <ul>
        <li><a href="https://www.iiitdmj.ac.in/downloads/Banking%20Facilities%20in%20PDPM%20IIITDM%20Jabalpur%20premises.pdf">Bank & ATM</a></li>
        <li><a href="https://iiitcouncil.com/">IIIT council</a></li>
        <li><a href="https://www.iiitdmj.ac.in/administration/senate.php">Senate</a></li>

      </ul>
    </div>
</div>
  <h6 style="text-align:center; color:#727171;"  >Last reviewed and updated on 26 Nov, 2019 </h6>

</div>